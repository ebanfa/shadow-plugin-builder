<?php

/*
 *
 */
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class PersonAPI  {

    /**
     *
     */
    public static function do_create_person($entity_data){
        return $entity_data;
    }

}