<?php

/*
 *
 */
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class PartyGroupAPI  {


    /**
     *
     */
    public static function do_create_party_group($entity_data){
        return $entity_data;
    }
    

}