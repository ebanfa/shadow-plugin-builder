<?php

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class UIComponentModel extends AbstractUIComponentModel { 
}
?>