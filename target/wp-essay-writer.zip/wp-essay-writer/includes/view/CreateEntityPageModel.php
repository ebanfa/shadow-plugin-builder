<?php

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}


class CreateEntityPageModel extends EntityPortalPageModel { 


}
?>