<?php

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}


class CreateContentOrderPageModel extends  CreateEntityPageModel { 

}
?>