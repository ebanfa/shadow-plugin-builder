<?php // the footer template file - contains the footer itself plus the closing body and html tags    ?>
</section>
<footer id="footer">
    Copyright &copy; 2015 Cloderia

    <ul class="f-menu">
        <li><a href="www.cloderia.com">Home</a></li>
        <li><a href="mailto:info@cloderia.com">Support</a></li>
        <li><a href="mailto:info@cloderia.com">Contact Us</a></li>
    </ul>
</footer>


<?php wp_footer(); ?>
</body>
</html>