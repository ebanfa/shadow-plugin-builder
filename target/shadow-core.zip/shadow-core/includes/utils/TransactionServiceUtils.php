<?php

/*
 *
 */
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class TransactionServiceUtils {


    /**
     *
     */
    public static function event_to_txn_data($financial_event_data) {
        return $financial_event_data;
    }

}

?>