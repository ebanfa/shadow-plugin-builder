<?php 

class FixedAssetCPT {

    public static $prefix = ''; 

    public static $post_name = 'sb_fixedasset'; 
    public static $is_global_entity = false; 


    public static $is_virtual_entity = false; 
    


    /**
     * These are the wordpress custom post type 
     * specific fields
     */
    public static $custom_fields =  array(
        array('name' => 'entity_code',
            'title' => 'Code',
            'description' => 'The Code field',
            'type' => 'text',
        ),
        array('name' => 'pfa_property',
            'title' => 'Property',
            'description' => 'The Property field',
            'type' => 'text',
        ),
        array('name' => 'pfa_dmethod',
            'title' => 'Depreciation Method',
            'description' => 'The Depreciation Method field',
            'type' => 'text',
        ),
        array('name' => 'pfa_assettype',
            'title' => 'Asset Type',
            'description' => 'The Asset Type field',
            'type' => 'text',
        ),
        array('name' => 'pfa_uom',
            'title' => 'Unit Of Measure',
            'description' => 'The Unit Of Measure field',
            'type' => 'text',
        ),
        array('name' => 'name',
            'title' => 'Name',
            'description' => 'The Name field',
            'type' => 'text',
        ),
        array('name' => 'description',
            'title' => 'Description',
            'description' => 'The Description field',
            'type' => 'text',
        ),
        array('name' => 'p_price',
            'title' => 'Purchase Amount',
            'description' => 'The Purchase Amount field',
            'type' => 'text',
        ),
        array('name' => 'date_acquired',
            'title' => 'Date Acquired',
            'description' => 'The Date Acquired field',
            'type' => 'text',
        ),
        array('name' => 'business_unit',
            'title' => 'Business Unit',
            'description' => 'The Business Unit field',
            'type' => 'text',
        ),
    );

    /**
     * These are the shadow banker framework 
     * specific fields. These represent the actual fields
     * defined in the entity mapping.
     */
 public static $entity_fields = array(
        'entity_code' => array('name' => 'entity_code',
            'description' => 'Code',
            'size' => 'medium',
            'data_type' => 'alphanumeric',
            'is_required' => false,
            'is_visible' => false,
            'is_create_field' => false,
            'is_edit_field' => false,
            'is_view_field' => false,
            'is_list_field' => false,
            'is_form_field' => false,
            'is_relationship_field' => false,),
        'pfa_property' => array('name' => 'pfa_property',
            'description' => 'Property',
            'size' => 'large',
            'entity_name' => 'Property',
            'entity_description' => 'Property',
            'data_type' => 'sb_property',
            'is_required' => true,
            'is_visible' => true,
            'is_create_field' => false,
            'is_edit_field' => false,
            'is_view_field' => false,
            'is_list_field' => false,
            'is_form_field' => false,
            'is_relationship_field' => true,),
        'pfa_dmethod' => array('name' => 'pfa_dmethod',
            'description' => 'Depreciation Method',
            'size' => 'large',
            'entity_name' => 'DeprecationMethod',
            'entity_description' => 'Depreciation Method',
            'data_type' => 'sb_dmethod',
            'is_required' => true,
            'is_visible' => true,
            'is_create_field' => true,
            'is_edit_field' => true,
            'is_view_field' => true,
            'is_list_field' => true,
            'is_form_field' => true,
            'is_relationship_field' => true,),
        'pfa_assettype' => array('name' => 'pfa_assettype',
            'description' => 'Asset Type',
            'size' => 'large',
            'entity_name' => 'FixedAssetType',
            'entity_description' => 'Fixed Asset Type',
            'data_type' => 'sb_fassettype',
            'is_required' => true,
            'is_visible' => true,
            'is_create_field' => true,
            'is_edit_field' => true,
            'is_view_field' => true,
            'is_list_field' => true,
            'is_form_field' => true,
            'is_relationship_field' => true,),
        'pfa_uom' => array('name' => 'pfa_uom',
            'description' => 'Unit Of Measure',
            'size' => 'large',
            'entity_name' => 'UnitOfMeasure',
            'entity_description' => 'Unit Of Measure',
            'data_type' => 'sb_uom',
            'is_required' => true,
            'is_visible' => true,
            'is_create_field' => true,
            'is_edit_field' => true,
            'is_view_field' => true,
            'is_list_field' => true,
            'is_form_field' => true,
            'is_relationship_field' => true,),
        'name' => array('name' => 'name',
            'description' => 'Name',
            'size' => 'large',
            'data_type' => 'name',
            'is_required' => true,
            'is_visible' => true,
            'is_create_field' => true,
            'is_edit_field' => true,
            'is_view_field' => true,
            'is_list_field' => true,
            'is_form_field' => true,
            'is_relationship_field' => false,),
        'description' => array('name' => 'description',
            'description' => 'Description',
            'size' => 'large',
            'data_type' => 'text-lg',
            'is_required' => true,
            'is_visible' => true,
            'is_create_field' => true,
            'is_edit_field' => true,
            'is_view_field' => true,
            'is_list_field' => true,
            'is_form_field' => true,
            'is_relationship_field' => false,),
        'p_price' => array('name' => 'p_price',
            'description' => 'Purchase Amount',
            'size' => 'medium',
            'data_type' => 'money',
            'is_required' => true,
            'is_visible' => true,
            'is_create_field' => true,
            'is_edit_field' => true,
            'is_view_field' => true,
            'is_list_field' => true,
            'is_form_field' => true,
            'is_relationship_field' => false,),
        'date_acquired' => array('name' => 'date_acquired',
            'description' => 'Date Acquired',
            'size' => 'medium',
            'data_type' => 'date',
            'is_required' => true,
            'is_visible' => true,
            'is_create_field' => true,
            'is_edit_field' => true,
            'is_view_field' => true,
            'is_list_field' => false,
            'is_form_field' => true,
            'is_relationship_field' => false,),
        'business_unit' => array('name' => 'business_unit',
            'description' => 'Business Unit',
            'size' => 'large',
            'entity_name' => 'BusinessUnit',
            'entity_description' => 'Business Unit',
            'data_type' => 'sb_businessunit',
            'is_required' => true,
            'is_visible' => false,
            'is_create_field' => false,
            'is_edit_field' => false,
            'is_view_field' => false,
            'is_list_field' => false,
            'is_form_field' => false,
            'is_relationship_field' => true,),
   );

    /**
     * These are the shadow banker framework 
     * specific fields. Inferred fields are fields that are not
     * directly defined in the entity mapping of a given entity, but are instead
     * inferred from other entities. As an example a Party entity has a field that
     * points to the PartyType of a party, ie Party points to PartyType but not vice versa.
     * So an array of Party entities will be an inferred field on PartyType.
     */
 public static $related_child_entities = array(
        'fixed_asset' => array('name' => 'fixed_asset',
            'entity_name' => 'PartyFixedAssetAssignment',
            'data_type' => 'sb_pfaassign',
            'artifact_name' => 'partyfixedassetassignment',
            'entity_description' => 'Party Fixed Asset Assignment',
            'is_relationship_field' => true,
            'fields' => array(
                'entity_code' => array('name' => 'entity_code',
                    'description' => 'Code',
                    'size' => 'medium',
                    'data_type' => 'alphanumeric',
                    'is_required' => false,
                    'is_visible' => false,
                    'is_create_field' => false,
                    'is_edit_field' => false,
                    'is_view_field' => false,
                    'is_list_field' => false,
                    'is_form_field' => false,
                    'is_relationship_field' => false,),
                'fixed_asset' => array('name' => 'fixed_asset',
                    'description' => 'Fixed Asset',
                    'size' => 'large',
                    'entity_name' => 'FixedAsset',
                    'entity_description' => 'Property Fixed Asset',
                    'data_type' => 'sb_fixedasset',
                    'is_required' => true,
                    'is_visible' => true,
                    'is_create_field' => true,
                    'is_edit_field' => true,
                    'is_view_field' => true,
                    'is_list_field' => true,
                    'is_form_field' => true,
                    'is_relationship_field' => true,),
                'party' => array('name' => 'party',
                    'description' => 'Party',
                    'size' => 'large',
                    'entity_name' => 'Party',
                    'entity_description' => 'Party',
                    'data_type' => 'sb_party',
                    'is_required' => true,
                    'is_visible' => true,
                    'is_create_field' => true,
                    'is_edit_field' => true,
                    'is_view_field' => true,
                    'is_list_field' => true,
                    'is_form_field' => true,
                    'is_relationship_field' => true,),
                'status' => array('name' => 'status',
                    'description' => 'Status',
                    'size' => 'large',
                    'entity_name' => 'PartyFixedAssetAssignmentStatus',
                    'entity_description' => 'Party Fixed Asset Assignment Status',
                    'data_type' => 'sb_wepastatus',
                    'is_required' => true,
                    'is_visible' => true,
                    'is_create_field' => true,
                    'is_edit_field' => true,
                    'is_view_field' => true,
                    'is_list_field' => true,
                    'is_form_field' => true,
                    'is_relationship_field' => true,),
                'from_date' => array('name' => 'from_date',
                    'description' => 'From Date',
                    'size' => 'medium',
                    'data_type' => 'date',
                    'is_required' => true,
                    'is_visible' => true,
                    'is_create_field' => true,
                    'is_edit_field' => true,
                    'is_view_field' => true,
                    'is_list_field' => true,
                    'is_form_field' => true,
                    'is_relationship_field' => false,),
                'to_date' => array('name' => 'to_date',
                    'description' => 'To Date',
                    'size' => 'medium',
                    'data_type' => 'date',
                    'is_required' => true,
                    'is_visible' => true,
                    'is_create_field' => true,
                    'is_edit_field' => true,
                    'is_view_field' => true,
                    'is_list_field' => true,
                    'is_form_field' => true,
                    'is_relationship_field' => false,),
                'name' => array('name' => 'name',
                    'description' => 'Name',
                    'size' => 'large',
                    'data_type' => 'name',
                    'is_required' => true,
                    'is_visible' => true,
                    'is_create_field' => true,
                    'is_edit_field' => true,
                    'is_view_field' => true,
                    'is_list_field' => true,
                    'is_form_field' => true,
                    'is_relationship_field' => false,),
                'alloc_cost' => array('name' => 'alloc_cost',
                    'description' => 'Allocated Cost',
                    'size' => 'large',
                    'data_type' => 'money',
                    'is_required' => true,
                    'is_visible' => true,
                    'is_create_field' => true,
                    'is_edit_field' => true,
                    'is_view_field' => true,
                    'is_list_field' => true,
                    'is_form_field' => true,
                    'is_relationship_field' => false,),
                'description' => array('name' => 'description',
                    'description' => 'Description',
                    'size' => 'large',
                    'data_type' => 'text-lg',
                    'is_required' => true,
                    'is_visible' => true,
                    'is_create_field' => true,
                    'is_edit_field' => true,
                    'is_view_field' => true,
                    'is_list_field' => true,
                    'is_form_field' => true,
                    'is_relationship_field' => false,),
                'business_unit' => array('name' => 'business_unit',
                    'description' => 'Business Unit',
                    'size' => 'large',
                    'entity_name' => 'BusinessUnit',
                    'entity_description' => 'Business Unit',
                    'data_type' => 'sb_businessunit',
                    'is_required' => true,
                    'is_visible' => false,
                    'is_create_field' => true,
                    'is_edit_field' => false,
                    'is_view_field' => true,
                    'is_list_field' => false,
                    'is_form_field' => false,
                    'is_relationship_field' => true,),
            ),
        ),
        'pfasset' => array('name' => 'pfasset',
            'entity_name' => 'Requirement',
            'data_type' => 'sb_requirement',
            'artifact_name' => 'requirement',
            'entity_description' => 'Requirement',
            'is_relationship_field' => true,
            'fields' => array(
                'entity_code' => array('name' => 'entity_code',
                    'description' => 'Code',
                    'size' => 'medium',
                    'data_type' => 'alphanumeric',
                    'is_required' => false,
                    'is_visible' => false,
                    'is_create_field' => false,
                    'is_edit_field' => false,
                    'is_view_field' => false,
                    'is_list_field' => false,
                    'is_form_field' => false,
                    'is_relationship_field' => false,),
                'r_type' => array('name' => 'r_type',
                    'description' => 'Requirement Type',
                    'size' => 'large',
                    'entity_name' => 'RequirementType',
                    'entity_description' => 'Requirement Type',
                    'data_type' => 'sb_requiretype',
                    'is_required' => true,
                    'is_visible' => true,
                    'is_create_field' => true,
                    'is_edit_field' => true,
                    'is_view_field' => true,
                    'is_list_field' => true,
                    'is_form_field' => true,
                    'is_relationship_field' => true,),
                'deliverable' => array('name' => 'deliverable',
                    'description' => 'Deliverable',
                    'size' => 'large',
                    'entity_name' => 'Deliverable',
                    'entity_description' => 'Deliverable',
                    'data_type' => 'sb_deliverable',
                    'is_required' => true,
                    'is_visible' => true,
                    'is_create_field' => true,
                    'is_edit_field' => true,
                    'is_view_field' => true,
                    'is_list_field' => true,
                    'is_form_field' => true,
                    'is_relationship_field' => true,),
                'pfasset' => array('name' => 'pfasset',
                    'description' => 'Fixed Asset',
                    'size' => 'large',
                    'entity_name' => 'FixedAsset',
                    'entity_description' => 'Property Fixed Asset',
                    'data_type' => 'sb_fixedasset',
                    'is_required' => true,
                    'is_visible' => true,
                    'is_create_field' => true,
                    'is_edit_field' => true,
                    'is_view_field' => true,
                    'is_list_field' => true,
                    'is_form_field' => true,
                    'is_relationship_field' => true,),
                'name' => array('name' => 'name',
                    'description' => 'Name',
                    'size' => 'large',
                    'data_type' => 'name',
                    'is_required' => true,
                    'is_visible' => true,
                    'is_create_field' => true,
                    'is_edit_field' => true,
                    'is_view_field' => true,
                    'is_list_field' => true,
                    'is_form_field' => true,
                    'is_relationship_field' => false,),
                'create_date' => array('name' => 'create_date',
                    'description' => 'Create Date',
                    'size' => 'medium',
                    'data_type' => 'date',
                    'is_required' => true,
                    'is_visible' => true,
                    'is_create_field' => true,
                    'is_edit_field' => true,
                    'is_view_field' => true,
                    'is_list_field' => true,
                    'is_form_field' => true,
                    'is_relationship_field' => false,),
                'require_date' => array('name' => 'require_date',
                    'description' => 'Required By Date',
                    'size' => 'medium',
                    'data_type' => 'date',
                    'is_required' => true,
                    'is_visible' => true,
                    'is_create_field' => true,
                    'is_edit_field' => true,
                    'is_view_field' => true,
                    'is_list_field' => true,
                    'is_form_field' => true,
                    'is_relationship_field' => false,),
                'budget_est' => array('name' => 'budget_est',
                    'description' => 'Estimated Budget',
                    'size' => 'large',
                    'data_type' => 'moeny',
                    'is_required' => true,
                    'is_visible' => true,
                    'is_create_field' => true,
                    'is_edit_field' => true,
                    'is_view_field' => true,
                    'is_list_field' => true,
                    'is_form_field' => true,
                    'is_relationship_field' => false,),
                'description' => array('name' => 'description',
                    'description' => 'Description',
                    'size' => 'large',
                    'data_type' => 'text-lg',
                    'is_required' => true,
                    'is_visible' => true,
                    'is_create_field' => true,
                    'is_edit_field' => true,
                    'is_view_field' => true,
                    'is_list_field' => true,
                    'is_form_field' => true,
                    'is_relationship_field' => false,),
                'quantity' => array('name' => 'quantity',
                    'description' => 'Quantity',
                    'size' => 'medium',
                    'data_type' => 'number',
                    'is_required' => true,
                    'is_visible' => true,
                    'is_create_field' => true,
                    'is_edit_field' => true,
                    'is_view_field' => true,
                    'is_list_field' => true,
                    'is_form_field' => true,
                    'is_relationship_field' => false,),
                'business_unit' => array('name' => 'business_unit',
                    'description' => 'Business Unit',
                    'size' => 'large',
                    'entity_name' => 'BusinessUnit',
                    'entity_description' => 'Business Unit',
                    'data_type' => 'sb_businessunit',
                    'is_required' => true,
                    'is_visible' => false,
                    'is_create_field' => false,
                    'is_edit_field' => false,
                    'is_view_field' => true,
                    'is_list_field' => true,
                    'is_form_field' => false,
                    'is_relationship_field' => true,),
            ),
        ),
   );
 
    /**
     * Register the custom post type so it shows up in menus
     */
    public static function register_custom_post_type()
    {
       register_post_type('sb_fixedasset', 
            array(
                'label' => 'Property Fixed Asset',
                'labels' => array(
                'add_new'           => 'Add New',
                'add_new_item'      => 'Add New Property Fixed Asset',
                'edit_item'         => 'Edit Property Fixed Asset',
                'new_item'          => 'New Property Fixed Asset',
                'view_item'         => 'View Property Fixed Asset',
                'search_items'      => 'Search Property Fixed Asset',
                'not_found'         => 'No Property Fixed Asset Found ',
                'not_found_in_trash'=> 'Not Found in Trash',
                ),
                'description' => 'Reusable Property Fixed Asset',
                'public' => true,
                'show_ui' => true,
                'menu_position' => 5,
                'supports' => array('title', 'custom-fields'),
                'has_archive'   => true,
                'rewrite'   => true,
            )
        );      
    }


    /*------------------------------------------------------------------------------
    Save the new Custom Fields values
    INPUT:
        $post_id (int) id of the post these custom fields are associated with
        $post (obj) the post object
  ------------------------------------------------------------------------------*/
    public static function save_custom_fields( $post_id, $post) 
    {
        if ( $post->post_type == 'sb_fixedasset') 
        {
            // The 2nd arg here is important because there are multiple nonces on the page
            if ( !empty($_POST))// && check_admin_referer('update_custom_content_fields','custom_content_fields_nonce') )
            {     
                CloderiaCustomFieldsUtils::save_custom_fields($post_id, $post, self::$custom_fields);
            }
        }
    }

    public static function get_field_value($content_type, $post_id, $field){
        return $field['value'];
    }

    public static function sb_fixedasset_table_head($defaults){
        $defaults['pfa_dmethod']  = 'Depreciation Method';
        $defaults['pfa_assettype']  = 'Asset Type';
        $defaults['pfa_uom']  = 'Unit Of Measure';
        $defaults['name']  = 'name';
        $defaults['description']  = 'Description';
        $defaults['p_price']  = 'Purchase Amount';
        return $defaults;
    }

    public static function sb_fixedasset_table_content($column_name, $post_id){
        if ($column_name == 'entity_code') {
            $field_value = get_post_meta($post_id, 'entity_code', true );
            echo $field_value;
        }
        if ($column_name == 'pfa_property') {
            $field_value = get_post_meta($post_id, 'pfa_property', true );
            echo $field_value;
        }
        if ($column_name == 'pfa_dmethod') {
            $field_value = get_post_meta($post_id, 'pfa_dmethod', true );
            echo $field_value;
        }
        if ($column_name == 'pfa_assettype') {
            $field_value = get_post_meta($post_id, 'pfa_assettype', true );
            echo $field_value;
        }
        if ($column_name == 'pfa_uom') {
            $field_value = get_post_meta($post_id, 'pfa_uom', true );
            echo $field_value;
        }
        if ($column_name == 'name') {
            $field_value = get_post_meta($post_id, 'name', true );
            echo $field_value;
        }
        if ($column_name == 'description') {
            $field_value = get_post_meta($post_id, 'description', true );
            echo $field_value;
        }
        if ($column_name == 'p_price') {
            $field_value = get_post_meta($post_id, 'p_price', true );
            echo $field_value;
        }
        if ($column_name == 'date_acquired') {
            $field_value = get_post_meta($post_id, 'date_acquired', true );
            echo $field_value;
        }
        if ($column_name == 'business_unit') {
            $field_value = get_post_meta($post_id, 'business_unit', true );
            echo $field_value;
        }
    }

}

?>