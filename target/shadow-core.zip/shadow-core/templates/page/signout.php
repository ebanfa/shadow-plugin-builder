<?php

/*
 *
 */
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

?>

<script type='text/javascript'>window.location='<?php echo wp_logout_url(home_url()); ?>'</script>