<?php

/*
 *
 */
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class ListPartyProfileView extends SinglePartyProfileView {

    /**
     *
     */
    function __construct() {
        parent::__construct();
        
    }

    
}

?>